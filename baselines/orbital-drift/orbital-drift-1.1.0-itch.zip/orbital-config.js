// Public configuration only. Never put an admin token here.
// Empty endpoint disables analytics; empty URLs suppress link sharing.
window.__ORBITAL_CONFIG__ = { analyticsEndpoint: '', officialUrl: '', playUrl: '', environment: 'production', platform: 'itch' };
